const http = require('http');
const Joi = require('joi')
const express = require('express');
const app = express();
app.use(express.json())
const courses = [

    {
        id: 1,
        name: "js"
    },

    {
        id: 2,
        name: "jshfgif"
    },
    {
        id: 3,
        name: "jsut"
    }
]
const server = http.createServer((req, res) => {




})


app.get('/', (req, res) => {

    res.send('Hello world');


});


app.get('/api/courses/:id', (req, res) => {

    const course = courses.find(c => c.id === parseInt(req.params.id));
    if (!course)
        res.status(404).send("the courses is not here");
    req.send(course)
})

app.get('/api/posts/:year/:month', (req, res) => {

    res.send(req.params);

})

//how to read query parameters
app.get('/api/posts/:year/:month', (req, res) => {

    res.send(req.query);

})



//ports environment variables
const port = process.env.PORT || 3000
app.listen(port, () => {

    console.log(`listening on port ${port} ....`);

})

//handling post requests



app.post('/api/courses', (req, res) => {

    const schema = {
        name: Joi.string().min(3).required()
    };
    const result = Joi.validate(req.body, schema);
    console.log(result);
    /*if(!req.body.name || req.body.name.length <3){

        res.status(400).send("name is required");
        return;
    }
    */
    if (result.error) {
        res.status(400).send(result.error.details[0].message)
    }

    const course = {
        //manually assign id
        id: courses.length + 1,
        name: req.body.name

    };
    courses.push(course);
    res.send(course);
});

//input validation

//joi



//Handling put requests updation

app.put('/api/courses/:id', (req, res) => {

    const course = courses.find(c => c.id === parseInt(req.params.id));
    if (!course)

        return res.status(404).send("the courses is not here");

    //second part is all about validation

    const result = validate(req.body);
    if (result.error)
        return res.status(400).send(result.error.details[0].message)




    //updation

    course.name = req.body.name;
    res.send(course);
})

function validate(course) {
    const schema = {
        name: Joi.string().min(3).required()
    };
    return Joi.validate(course, schema);
}

//http delete request

app.delete('/api/courses/:id', (req, res) => {


    const course = courses.find(c => c.id === parseInt(req.params.id));
    if (!course)
        return res.status(404).send("the courses is not here");

    //Delete
    const index = courses.indexOf(course)
    courses.splice(index, 1)

    //return 
    res.send(course);

})

//Bug fixes

//use return in the route handler